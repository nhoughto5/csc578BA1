#ifndef GENERATED_SHADERPATHS
#define GENERATED_SHADERPATHS

#pragma once

#include <string>

namespace generated
{
    class ShaderPaths
    {
    public:
        static std::string getShaderDirectory()
        {
            return "C:/Users/Nick/Desktop/NickTop/HomeWork/Elec 578B/AtlasClone/uvic-animation/Cloth/shaders/";
        }
    };
}

#endif

